package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings({ "serial", "unused" })
public class MainScreen extends JPanel{
	
	private JLabel bckgnd;
	public JButton btn;
	
	public MainScreen() {
		this.setLayout(new GridBagLayout());
		btn = new JButton(new ImageIcon("pokebtn.png"));
		btn.setOpaque(false);
		btn.setBorderPainted(false);
		btn.setFocusable(false);
		btn.setContentAreaFilled(false);
		this.add(btn,new GridBagConstraints());
		btn.setName("Start");
	}
	@Override
	  protected void paintComponent(Graphics g) {

	    super.paintComponent(g);
	    Image bgImage;
	    ImageIcon i = new ImageIcon("title.png");
	    bgImage= i.getImage();
	        g.drawImage(bgImage, 0, 0, this.getSize().width, this.getSize().height, this);
	}
}
