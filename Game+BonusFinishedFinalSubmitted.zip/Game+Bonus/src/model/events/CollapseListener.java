package model.events;

import model.infrastructure.ResidentialBuilding;

public interface CollapseListener {
public void ChangeIcon(ResidentialBuilding b);
}
