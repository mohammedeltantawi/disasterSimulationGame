package model.events;

import model.people.Citizen;

public interface DeathListener {
public void changeIcon(Citizen c);
}
